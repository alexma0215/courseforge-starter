import { onCall, HttpsError } from 'firebase-functions/v2/https';
import * as admin from 'firebase-admin';
export const publishCourse = onCall(async (req)=>{
  const uid = req.auth?.uid; if(!uid) throw new HttpsError('unauthenticated','Login required');
  const { courseId } = req.data as { courseId:string };
  const ref = admin.firestore().doc(`courses/${courseId}`);
  const snap = await ref.get();
  if(!snap.exists) throw new HttpsError('not-found','Course not found');
  if(snap.get('ownerId') !== uid) throw new HttpsError('permission-denied','Not owner');
  const publicId = (Math.random().toString(36).slice(2)+Date.now().toString(36)).slice(0,16);
  await admin.firestore().doc(`shares/${publicId}`).set({ courseId, enabled:true });
  await ref.set({ status:'published', publicId }, { merge:true });
  return { publicId };
});
