import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { Storage } from '@google-cloud/storage';
import puppeteer from 'puppeteer';

const storage = new Storage();
export const exportPdf = onCall(async (req)=>{
  const { publicId } = req.data as { publicId:string };
  if(!publicId) throw new HttpsError('invalid-argument','Missing publicId');
  const url = `${process.env.SHARE_BASE_URL}/${publicId}`;
  const browser = await puppeteer.launch({ args:['--no-sandbox','--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  await page.goto(url, { waitUntil:'networkidle0' });
  const pdf = await page.pdf({ format:'A4', printBackground:true });
  await browser.close();
  const bucket = storage.bucket(process.env.GCS_BUCKET!);
  const path = `exports/${publicId}/${Date.now()}.pdf`;
  await bucket.file(path).save(pdf, { contentType:'application/pdf' });
  await bucket.file(path).makePublic();
  return { url: `https://storage.googleapis.com/${bucket.name}/${path}` };
});
