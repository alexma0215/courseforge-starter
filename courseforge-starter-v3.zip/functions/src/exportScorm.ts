import { onCall, HttpsError } from 'firebase-functions/v2/https';
import * as admin from 'firebase-admin';
import JSZip from 'jszip';
import { Storage } from '@google-cloud/storage';

const storage = new Storage();
export const exportScorm = onCall(async (req)=>{
  const { publicId } = req.data as { publicId: string };
  if(!publicId) throw new HttpsError('invalid-argument','Missing publicId');
  const share = await admin.firestore().doc(`shares/${publicId}`).get();
  if(!share.exists) throw new HttpsError('not-found','Share not found');
  const courseId = share.get('courseId') as string;
  const course = await admin.firestore().doc(`courses/${courseId}`).get();
  const lessons = await admin.firestore().collection(`courses/${courseId}/lessons`).get();
  const data = { title: course.get('title'), lessons: lessons.docs.map(d=>({ id:d.id, ...d.data() })) };

  const zip = new JSZip();
  zip.file('index.html', `<!doctype html><html><head><meta charset="utf-8"><title>${data.title}</title></head>
  <body><h1>${data.title}</h1><div id="app"></div><script src="scorm-api.js"></script><script src="player.js"></script></body></html>`);
  zip.file('scorm-api.js', `/* Minimal SCORM 1.2 API shim */`);
  zip.file('player.js', `const course=${JSON.stringify(data)};
  const app=document.getElementById('app');
  course.lessons.forEach(l=>{const s=document.createElement('section');s.innerHTML='<h2>'+l.title+'</h2>'; (l.blocks||[]).forEach(b=>{if(b.type==='heading')s.innerHTML+='<h3>'+b.text+'</h3>'; if(b.type==='markdown')s.innerHTML+='<div>'+b.text.replace(/</g,'&lt;')+'</div>';}); app.appendChild(s);});`);

  const buffer = await zip.generateAsync({ type: 'nodebuffer' });
  const bucket = storage.bucket(process.env.GCS_BUCKET!);
  const path = `exports/${publicId}/${Date.now()}.zip`;
  await bucket.file(path).save(buffer, { contentType:'application/zip' });
  await bucket.file(path).makePublic();
  return { url: `https://storage.googleapis.com/${bucket.name}/${path}` };
});
