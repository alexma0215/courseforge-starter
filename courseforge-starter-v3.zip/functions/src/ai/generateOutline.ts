import { onCall, HttpsError } from 'firebase-functions/v2/https';
import * as admin from 'firebase-admin';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { enforceLimits } from '../limits.js';

const genai = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export const generateOutline = onCall(async (req) => {
  const uid = req.auth?.uid; if (!uid) throw new HttpsError('unauthenticated','Login required');
  const { topic } = req.data as { topic: string };
  if (!topic) throw new HttpsError('invalid-argument','Missing topic');

  const check = await enforceLimits(uid,'aiCreationsPerMonth');
  if (!(check as any).ok) throw new HttpsError('failed-precondition',(check as any).reason);

  const model = genai.getGenerativeModel({ model: 'gemini-1.5-pro' });
  const prompt = `Devuelve SOLO JSON con {"title":"${topic}","subtopics":[{"title":string,"objectives":string[]}]} con 5-8 subtopics.`;
  const resp = await model.generateContent(prompt);
  const json = JSON.parse(resp.response.text());

  const courseRef = await admin.firestore().collection('courses').add({
    ownerId: uid, title: json.title, status: 'draft', createdAt: Date.now(), updatedAt: Date.now(), theme: {}
  });

  const batch = admin.firestore().batch();
  (json.subtopics||[]).forEach((s:any)=>{
    const ref = courseRef.collection('lessons').doc();
    batch.set(ref, { title: s.title, objectives: s.objectives||[], blocks: [] });
  });
  await batch.commit();
  await admin.firestore().doc(`users/${uid}`).set({ aiCreationsThisMonth: admin.firestore.FieldValue.increment(1) }, { merge: true });

  return { courseId: courseRef.id, count: (json.subtopics||[]).length };
});
