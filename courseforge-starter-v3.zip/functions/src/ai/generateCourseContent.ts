import { onCall, HttpsError } from 'firebase-functions/v2/https';
import * as admin from 'firebase-admin';
import { GoogleGenerativeAI } from '@google/generative-ai';

const genai = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export const generateCourseContent = onCall(async (req) => {
  const uid = req.auth?.uid; if (!uid) throw new HttpsError('unauthenticated','Login required');
  const { courseId } = req.data as { courseId: string };
  if (!courseId) throw new HttpsError('invalid-argument','Missing courseId');

  const courseRef = admin.firestore().doc(`courses/${courseId}`);
  const course = await courseRef.get();
  if (!course.exists) throw new HttpsError('not-found','Course not found');
  if (course.get('ownerId') !== uid) throw new HttpsError('permission-denied','Not owner');

  const lessons = await admin.firestore().collection(`courses/${courseId}/lessons`).get();
  const model = genai.getGenerativeModel({ model: 'gemini-1.5-pro' });

  await Promise.all(lessons.docs.map(async d=>{
    const title = d.get('title');
    const p = `Devuelve SOLO JSON con "blocks":[
      {"type":"heading","text":string},
      {"type":"markdown","text":string},
      {"type":"markdown","text":string},
      {"type":"quiz","items":[{"q":string,"type":"single","options":[string,string,string,string],"answer":number}]}
    ] (cada markdown ≤120 palabras). Curso:${course.get('title')}, Subtema:${title}`;
    const r = await model.generateContent(p);
    const data = JSON.parse(r.response.text());
    await d.ref.set({ blocks: data.blocks }, { merge: true });
  }));

  await courseRef.set({ updatedAt: Date.now() }, { merge: true });
  return { ok:true };
});
