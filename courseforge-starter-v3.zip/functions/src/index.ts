import * as admin from 'firebase-admin';
import { generateOutline } from './ai/generateOutline.js';
import { generateCourseContent } from './ai/generateCourseContent.js';
import { publishCourse } from './publishCourse.js';
import { exportPdf } from './exportPdf.js';
import { exportScorm } from './exportScorm.js';
if(!admin.apps.length) admin.initializeApp();
export { generateOutline, generateCourseContent, publishCourse, exportPdf, exportScorm };
