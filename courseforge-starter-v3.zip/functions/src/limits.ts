import * as admin from 'firebase-admin';
export async function enforceLimits(uid: string, key: 'aiCreationsPerMonth'|'workspaceCourses') {
  const ref = admin.firestore().doc(`billing/${uid}`);
  const snap = await ref.get();
  const limits = (snap.get('limits') as any) || { aiCreationsPerMonth: 50, workspaceCourses: 9999 };
  if (key === 'aiCreationsPerMonth') {
    const used = (snap.get('aiCreationsThisMonth') as number) || 0;
    if (used >= limits.aiCreationsPerMonth) return { ok:false, reason:'Monthly AI creation limit reached' };
  }
  if (key === 'workspaceCourses') {
    const q = await admin.firestore().collection('courses').where('ownerId','==',uid).get();
    if (q.size >= limits.workspaceCourses) return { ok:false, reason:'Workspace course limit reached' };
  }
  return { ok:true };
}
