'use client';
import { httpsCallable } from 'firebase/functions';
import { functions } from '../lib/firebase';
import { useState } from 'react';
export default function DownloadDialog({ publicId }:{ publicId:string }){
  const [busy,setBusy]=useState(false);
  async function run(name:string){
    setBusy(true);
    try{
      const fn = httpsCallable(functions, name);
      const res:any = await fn({ publicId });
      if(res?.data?.url) window.open(res.data.url,'_blank');
    } finally { setBusy(false); }
  }
  return (<div className="card">
    <h3 style={{marginTop:0}}>Descargar curso</h3>
    <div className="grid">
      <button className="btn" onClick={()=>run('exportPdf')} disabled={busy}>PDF</button>
      <button className="btn" onClick={()=>run('exportScorm')} disabled={busy}>SCORM</button>
      <button className="btn secondary" disabled>Otro</button>
    </div>
  </div>);
}
