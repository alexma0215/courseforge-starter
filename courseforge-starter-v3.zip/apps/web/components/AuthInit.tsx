'use client';
import { useEffect } from 'react';
import { auth } from '../lib/firebase';
import { signInAnonymously, onAuthStateChanged } from 'firebase/auth';

export default function AuthInit(){
  useEffect(()=>{
    // Try to sign-in anonymously; ignore if already signed-in.
    const unsub = onAuthStateChanged(auth, (u)=>{ if(!u) signInAnonymously(auth).catch(()=>{}); });
    return () => unsub();
  },[]);
  return null;
}
