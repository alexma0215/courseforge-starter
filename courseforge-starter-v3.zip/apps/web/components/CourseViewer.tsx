'use client';
import { marked } from 'marked';
export function CourseViewer({ course }:{course:any}){
  if (!course) return <div>No encontrado</div>;
  return (<main>
    <h1 style={{marginTop:0}}>{course.title}</h1>
    {course.lessons?.map((l:any)=>(
      <section key={l.id} className="card">
        <h2>{l.title}</h2>
        {(l.blocks||[]).map((b:any,i:number)=>{
          if(b.type==='heading') return <h3 key={i}>{b.text}</h3>;
          if(b.type==='markdown') return <div key={i} dangerouslySetInnerHTML={{__html: marked.parse(b.text||'')}}/>;
          if(b.type==='video') return <video key={i} controls src={b.url} style={{width:'100%'}}/>;
          if(b.type==='quiz') return <div key={i} className="badge">Quiz incluido</div>;
          return null;
        })}
      </section>
    ))}
  </main>);
}
