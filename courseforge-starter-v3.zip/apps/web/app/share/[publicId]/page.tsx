'use client';
import { useEffect, useState } from 'react';
import { db } from '../../../lib/firebase';
import { doc, getDoc, collection, getDocs } from 'firebase/firestore';
import DownloadDialog from '../../../components/DownloadDialog';
import { CourseViewer } from '../../../components/CourseViewer';

export default function Share({ params:{publicId} }:{params:{publicId:string}}){
  const [course,setCourse]=useState<any>(null);
  useEffect(()=>{ (async()=>{
    const s=await getDoc(doc(db as any,'shares',publicId)); if(!s.exists()) return;
    const cId=s.data().courseId;
    const c=await getDoc(doc(db as any,'courses',cId));
    const l=await getDocs(collection(db as any,`courses/${cId}/lessons`));
    setCourse({id:c.id,...c.data(),lessons:l.docs.map(d=>({id:d.id,...d.data()}))});
  })(); },[publicId]);
  return (<div>
    <CourseViewer course={course}/>
    <div style={{height:16}}/>
    <DownloadDialog publicId={publicId}/>
  </div>);
}
