import './globals.css';
import AuthInit from '../components/AuthInit';
export const metadata = { title: 'CourseForge', description: 'Course authoring with Firebase' };
export default function RootLayout({ children }:{ children:React.ReactNode }){
  return (<html lang="es"><body>
    <div className="header"><div className="container" style={{display:'flex',gap:16,alignItems:'center'}}>
      <a href="/" style={{textDecoration:'none',color:'#111',fontWeight:700}}>CourseForge</a>
      <a href="/dashboard">Dashboard</a>
      <a href="/pricing">Pricing</a>
    </div></div>
    <AuthInit />
        <div className="container">{children}</div>
  </body></html>);
}
