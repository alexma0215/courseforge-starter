'use client';
import { useEffect, useState } from 'react';
import { db } from '../../../lib/firebase';
import { doc, getDoc, collection, getDocs } from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { functions } from '../../../lib/firebase';

export default function Editor({ params:{courseId} }:{params:{courseId:string}}){
  const [course,setCourse]=useState<any>(null);
  const [lessons,setLessons]=useState<any[]>([]);
  useEffect(()=>{ (async()=>{
    const c=await getDoc(doc(db as any,'courses',courseId));
    setCourse({id:c.id,...c.data()});
    const l=await getDocs(collection(db as any,`courses/${courseId}/lessons`));
    setLessons(l.docs.map(d=>({id:d.id,...d.data()})));
  })(); },[courseId]);

  async function gen(){
    const fn=httpsCallable(functions,'generateCourseContent'); await fn({ courseId }); location.reload();
  }
  async function pub(){
    const fn=httpsCallable(functions,'publishCourse'); const r:any = await fn({ courseId });
    if(r?.data?.publicId) location.href=`/share/${r.data.publicId}`;
  }
  if(!course) return <div>Cargando…</div>;
  return (<div>
    <h1>Editor — {course.title}</h1>
    <div className="grid">
      <button className="btn" onClick={gen}>Generar contenido</button>
      <button className="btn" onClick={pub}>Publicar</button>
    </div>
    <h2>Lecciones</h2>
    {lessons.map(l=>(<div key={l.id} className="card">
      <div style={{fontWeight:600}}>{l.title}</div>
      <div className="mono">{JSON.stringify(l.blocks||[],null,2)}</div>
    </div>))}
  </div>);
}
