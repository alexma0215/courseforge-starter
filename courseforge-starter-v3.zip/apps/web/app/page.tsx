'use client';
import { useState } from 'react';
import { httpsCallable } from 'firebase/functions';
import { functions } from '../lib/firebase';

export default function Home(){
  const [topic,setTopic]=useState('Inteligencia Artificial en educación');
  const [busy,setBusy]=useState(false);
  async function go(){
    setBusy(true);
    try{
      const gen = httpsCallable(functions,'generateOutline');
      const res:any = await gen({ topic });
      if(res?.data?.courseId) window.location.href = `/editor/${res.data.courseId}`;
    } finally { setBusy(false); }
  }
  return (<div>
    <h1 style={{marginTop:0}}>Generar curso con IA</h1>
    <p>Escribe un tema. Generamos 5–8 subtemas y luego el contenido.</p>
    <input className="input" value={topic} onChange={e=>setTopic(e.target.value)} />
    <div style={{height:12}}/>
    <button className="btn" onClick={go} disabled={busy}>{busy?'Generando…':'Generar outline'}</button>
  </div>);
}
